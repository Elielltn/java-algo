
package CafeManegementSystem;

public class CafeManegementSystem {
    
}
