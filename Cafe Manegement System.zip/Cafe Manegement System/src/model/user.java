/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author Lucas
 */
public class user {
    private int id;
    private String name;
    private String email;
    private String mobileNumber;
    private String address;
    private String password;
    private String securityQuestion;
    private String aswer;
    
}
